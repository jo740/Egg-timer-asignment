import Cocoa

var greeting = "Hello, playground"
